package com.cg.demo.dto;

public class Triangle {
      int size;
      String type;
      
      public void getSize()   
      {
    	  
      }
}
