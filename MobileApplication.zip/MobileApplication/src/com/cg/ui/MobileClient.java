package com.cg.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.dto.Mobile;
import com.cg.service.MobileService;
import com.cg.service.MobileServiceImpl;

public class MobileClient {

	public static void main(String[] args){
	MobileService mser=new MobileServiceImpl();
	int choice;
	Scanner sc=new Scanner(System.in);
	do{
		System.out.println("1.Add Mobile");
		System.out.println("2.Update Mobile");
		System.out.println("3.Search Mobile");
		System.out.println("4.Delete Mobile");
		System.out.println("5.Get Mobile list");
		System.out.println("6.Fetch mobile within range");
		System.out.println("7.Exit");
		System.out.println("Enter your choice:");
		choice=sc.nextInt();
		switch(choice){
		case 1:
			System.out.println("Enter Mobile name");
			String mname=sc.next();
			System.out.println("Enter price:");
			double price=sc.nextDouble();
			System.out.println("Enter quantity");
			int qty=sc.nextInt();
			Mobile mobile=new Mobile();
			mobile.setMname(mname);
			mobile.setPrice(price);
			mobile.setQty(qty);
			mser.addMobile(mobile);
			System.out.println("Mobile details added");
			break;
		case 2:
			System.out.println("Enter id to update mobile");
			int mid=sc.nextInt();
			Mobile mobile1=mser.findMobile(mid);
			System.out.println("Enter Name of mobile:");
			sc.nextLine();
			String mname1=sc.nextLine();
			System.out.println("Enter price:");
			double price1=sc.nextDouble();
			System.out.println("Enter quantity");
			int qty1=sc.nextInt();
			
			mobile1.setMname(mname1);
			mobile1.setPrice(price1);
			mobile1.setQty(qty1);
			mser.updateMobile(mobile1);
			System.out.println("Mobile details updated");
		    break;
		case 3:
			System.out.println("Enter mobile id to search:");
			int mid1=sc.nextInt();
			Mobile mobile2=mser.findMobile(mid1);
			System.out.println(mobile2);
			break;
		case 4:
			System.out.println("Enter mobile id to be deleted:");
			int mid2=sc.nextInt();
			Mobile mobile3=mser.findMobile(mid2);
			mser.deleteMobile(mobile3);
			System.out.println("Mobile details deleted");
			break;
	    case  5:
	    	List<Mobile> mlist=mser.getAllMobiles();
	    	for(Mobile m:mlist){
	    		System.out.println(m);
	    	}
	    	break;
	    case 6:
	    	System.out.println("Enter minimum price");
	    	double minPrice=sc.nextDouble();
	    	System.out.println("Enter maximum price:");
	    	double maxPrice=sc.nextDouble();
	    	List<Mobile> mlist1=mser.fetchMobileInPriceRange(minPrice, maxPrice);
	    	for(Mobile m:mlist1){
	    		System.out.println(m);
	    	}
	    	break;
		case 7:
			System.exit(0);
			break;
         }
	   }
	while(true);
	}
}
